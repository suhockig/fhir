module.exports = {
    TIMEOUT      : 15000, // timeout when waiting for something
    PAUSE        : 800,   // pause between interactions so that humans can see wait is going on
    PICKER_URL   : "http://localhost:9001/#/",
};