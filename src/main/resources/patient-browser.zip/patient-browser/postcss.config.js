module.exports = {
    use: [ require('autoprefixer') ]
}